package com.example.testfilesender

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileWriter

/**
 * MainActivity — the single screen of this proof-of-concept app.
 *
 * What it does:
 *   1. Lets the user type text into a text box.
 *   2. On "Send Test File", writes that text to a temporary .txt file.
 *   3. Opens the standard Android share/email chooser so the user's own
 *      mail app can send the file as an attachment.
 *
 * What it does NOT do:
 *   - No background services, no networking, no analytics, no tracking.
 *   - No direct SMTP or mail-server connections.
 *   - No data leaves the device except through the user-visible share intent.
 */
class MainActivity : AppCompatActivity() {

    // ── Configurable defaults (edit these for your test) ────────────────
    companion object {
        /** Pre-filled recipient email address. Change as needed. */
        const val DEFAULT_RECIPIENT = "test@example.com"

        /** Pre-filled email subject line. Change as needed. */
        const val DEFAULT_SUBJECT = "Test File from TestFileSender PoC"

        /** Name of the temporary text file that gets attached. */
        const val ATTACHMENT_FILENAME = "test_output.txt"
    }
    // ────────────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val editText: EditText = findViewById(R.id.editTextContent)
        val sendButton: Button = findViewById(R.id.buttonSend)

        sendButton.setOnClickListener {
            val userText = editText.text.toString().trim()

            if (userText.isEmpty()) {
                Toast.makeText(this, "Please enter some text first.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            try {
                val file = writeTextToFile(userText)
                shareFileViaEmail(file)
            } catch (e: Exception) {
                Toast.makeText(
                    this,
                    "Error: ${e.localizedMessage}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    /**
     * Writes [text] to a temporary .txt file in the app's private cache
     * directory. Returns the File handle.
     */
    private fun writeTextToFile(text: String): File {
        // Use a subdirectory that matches file_paths.xml configuration
        val sharedDir = File(cacheDir, "shared_files")
        if (!sharedDir.exists()) sharedDir.mkdirs()

        val file = File(sharedDir, ATTACHMENT_FILENAME)
        FileWriter(file).use { writer ->
            writer.write(text)
        }
        return file
    }

    /**
     * Opens the standard Android email/share chooser with:
     *   - The given file as an attachment (via FileProvider URI)
     *   - A pre-filled recipient and subject line
     *
     * The user's own mail app handles the actual sending — this app
     * never connects to any server directly.
     */
    private fun shareFileViaEmail(file: File) {
        val uri = FileProvider.getUriForFile(
            this,
            "${applicationContext.packageName}.fileprovider",
            file
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_EMAIL, arrayOf(DEFAULT_RECIPIENT))
            putExtra(Intent.EXTRA_SUBJECT, DEFAULT_SUBJECT)
            putExtra(Intent.EXTRA_TEXT, "Please see the attached test file.")
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        // Let the user choose which app to use
        startActivity(Intent.createChooser(intent, "Send test file via…"))
    }
}
