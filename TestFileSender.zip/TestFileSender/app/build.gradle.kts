plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.testfilesender"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.testfilesender"
        minSdk = 24          // Android 7.0+
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0-poc"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // No ProGuard / R8 obfuscation — keeps code fully auditable
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Standard AndroidX libraries only — nothing third-party
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
}
