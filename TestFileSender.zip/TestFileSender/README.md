# TestFileSender — Minimal Android PoC

A transparent, minimal proof-of-concept Android app for authorized internal testing.

**What it does:** Lets you type text, saves it to a `.txt` file, and opens the standard Android share/email chooser so your installed mail app can send it as an attachment.

**What it does NOT do:** No analytics, no tracking, no ads, no background services, no internet access, no push notifications, no account system, no remote config, no obfuscation.

---

## Project structure

```
TestFileSender/
├── app/
│   ├── build.gradle.kts              ← App build config (2 dependencies)
│   └── src/main/
│       ├── AndroidManifest.xml        ← Zero permissions, one activity
│       ├── java/.../MainActivity.kt   ← The only Kotlin file (~90 lines)
│       └── res/
│           ├── layout/activity_main.xml
│           ├── values/strings.xml
│           ├── values/themes.xml
│           └── xml/file_paths.xml     ← FileProvider config
├── build.gradle.kts                   ← Root build file
├── settings.gradle.kts
├── gradle.properties
└── README.md                          ← This file
```

---

## Configuration

To change the default recipient email or subject line, edit the companion object at the top of `MainActivity.kt`:

```kotlin
companion object {
    const val DEFAULT_RECIPIENT = "test@example.com"
    const val DEFAULT_SUBJECT   = "Test File from TestFileSender PoC"
    const val ATTACHMENT_FILENAME = "test_output.txt"
}
```

---

## Build instructions (Android Studio)

1. **Install Android Studio** (Hedgehog 2023.1.1 or newer recommended).
2. **Open the project:** File → Open → select the `TestFileSender/` root folder.
3. **Wait for Gradle sync** to complete (it will download standard Android SDK components if needed).
4. **Build the APK:**
   - Menu: Build → Build Bundle(s) / APK(s) → Build APK(s)
   - Or from terminal inside the project: `./gradlew assembleDebug`
   - The debug APK will be at: `app/build/outputs/apk/debug/app-debug.apk`

---

## Install on a device

### Option A — Android Studio (recommended)
1. Connect your device via USB with USB debugging enabled.
2. Click the **Run ▶** button in Android Studio.
3. Select your device. The app installs and launches automatically.

### Option B — ADB sideload
1. Enable **Developer Options** and **USB Debugging** on the device.
2. Connect via USB and run:
   ```bash
   adb install app/build/outputs/apk/debug/app-debug.apk
   ```
3. Open "TestFileSender" from the app drawer.

### Option C — Direct APK transfer
1. Copy the `.apk` file to the device (email, file manager, etc.).
2. On the device, open the APK and allow "Install from unknown sources" when prompted.

---

## Uninstall

### From the device
- Long-press the app icon → Uninstall, or
- Settings → Apps → TestFileSender → Uninstall

### Via ADB
```bash
adb uninstall com.example.testfilesender
```

---

## Security & audit checklist

| # | Check | Status |
|---|-------|--------|
| 1 | **No INTERNET permission** — `AndroidManifest.xml` declares zero `<uses-permission>` entries. | ✅ Pass |
| 2 | **No background services** — No `<service>` in manifest. | ✅ Pass |
| 3 | **No broadcast receivers** — No `<receiver>` in manifest. | ✅ Pass |
| 4 | **No analytics / tracking SDKs** — `build.gradle.kts` lists only `core-ktx` and `appcompat`. | ✅ Pass |
| 5 | **No Firebase, Google Play Services, or ads** — Not in dependencies. | ✅ Pass |
| 6 | **No remote config** — App has no network calls at all. | ✅ Pass |
| 7 | **No push notifications** — No FCM, no notification channels registered. | ✅ Pass |
| 8 | **No account system** — No `AccountManager`, no login UI. | ✅ Pass |
| 9 | **No obfuscation** — `isMinifyEnabled = false` in release build. | ✅ Pass |
| 10 | **File sharing uses user-visible intent only** — `Intent.ACTION_SEND` with `createChooser()`. User explicitly picks the sending app. | ✅ Pass |
| 11 | **File written to private cache only** — Uses `cacheDir/shared_files/`, not external storage. | ✅ Pass |
| 12 | **Entire codebase is one Kotlin file (~90 lines)** — Easy to read end-to-end. | ✅ Pass |
| 13 | **Transparency note in UI** — The app screen explains what it does and doesn't do. | ✅ Pass |
| 14 | **allowBackup=false** — No automatic cloud backup of app data. | ✅ Pass |

### How to verify yourself

```bash
# 1. Check manifest for permissions (should print nothing)
grep "uses-permission" app/src/main/AndroidManifest.xml

# 2. Check manifest for services/receivers (should print nothing)
grep -E "<service|<receiver" app/src/main/AndroidManifest.xml

# 3. Check dependencies (should show only core-ktx and appcompat)
grep "implementation" app/build.gradle.kts

# 4. Count Kotlin source files (should be 1)
find . -name "*.kt" | wc -l

# 5. Search for any URL/HTTP strings in source (should find nothing)
grep -ri "http" app/src/main/java/
```

---

## License

Internal use only — authorized testing with dummy data.
