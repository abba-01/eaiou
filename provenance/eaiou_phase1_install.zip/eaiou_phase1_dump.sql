/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.4.10-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: eaiou_eaiou
-- ------------------------------------------------------
-- Server version	11.4.10-MariaDB-ubu2404

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `xd6w5_eaiou_papers`
--

DROP TABLE IF EXISTS `xd6w5_eaiou_papers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `xd6w5_eaiou_papers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `article_id` int(11) NOT NULL COMMENT 'joomla xd6w5_content.id',
  `paper_uuid` char(36) NOT NULL COMMENT 'matches paper_id custom field on article',
  `authorship_mode` enum('human','ai','hybrid') NOT NULL DEFAULT 'human',
  `status` varchar(50) NOT NULL DEFAULT 'draft',
  `submission_version` int(11) NOT NULL DEFAULT 1,
  `doi` varchar(255) DEFAULT NULL,
  `authors_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`authors_json`)),
  `submission_sealed_at` datetime DEFAULT NULL COMMENT 'sealed at submission — never displayed publicly',
  `sealed_by` int(11) DEFAULT NULL COMMENT 'user_id who triggered sealing',
  `submission_hash` varchar(64) DEFAULT NULL COMMENT 'SHA256(paper_uuid+submission_sealed_at+content_hash)',
  `submission_capstone` varchar(255) DEFAULT NULL COMMENT 'Zenodo DOI — public receipt without revealing timing',
  `acceptance_sealed_at` datetime DEFAULT NULL COMMENT 'sealed at acceptance — never displayed publicly',
  `publication_sealed_at` datetime DEFAULT NULL COMMENT 'sealed at publication — never displayed publicly',
  `bundle_path` varchar(500) DEFAULT NULL,
  `q_signal` decimal(7,4) DEFAULT NULL COMMENT 'denormalized from eaiou_quality_signals — discovery sort key',
  `state` tinyint(4) NOT NULL DEFAULT 1,
  `access` int(11) NOT NULL DEFAULT 1,
  `ordering` int(11) NOT NULL DEFAULT 0,
  `created` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `checked_out` int(11) DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `paper_uuid` (`paper_uuid`),
  KEY `idx_article_id` (`article_id`),
  KEY `idx_status` (`status`),
  KEY `idx_q_signal` (`q_signal`),
  KEY `idx_authorship` (`authorship_mode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xd6w5_eaiou_papers`
--

LOCK TABLES `xd6w5_eaiou_papers` WRITE;
/*!40000 ALTER TABLE `xd6w5_eaiou_papers` DISABLE KEYS */;
/*!40000 ALTER TABLE `xd6w5_eaiou_papers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xd6w5_eaiou_versions`
--

DROP TABLE IF EXISTS `xd6w5_eaiou_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `xd6w5_eaiou_versions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) NOT NULL COMMENT 'fk eaiou_papers.id',
  `label` varchar(100) NOT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `content_hash` varchar(64) DEFAULT NULL,
  `ai_flag` tinyint(4) NOT NULL DEFAULT 0,
  `ai_model_name` varchar(255) DEFAULT NULL,
  `generated_at` datetime DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `state` tinyint(4) NOT NULL DEFAULT 1,
  `access` int(11) NOT NULL DEFAULT 1,
  `ordering` int(11) NOT NULL DEFAULT 0,
  `created` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `checked_out` int(11) DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_paper_id` (`paper_id`),
  KEY `idx_ai_flag` (`ai_flag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xd6w5_eaiou_versions`
--

LOCK TABLES `xd6w5_eaiou_versions` WRITE;
/*!40000 ALTER TABLE `xd6w5_eaiou_versions` DISABLE KEYS */;
/*!40000 ALTER TABLE `xd6w5_eaiou_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xd6w5_eaiou_ai_sessions`
--

DROP TABLE IF EXISTS `xd6w5_eaiou_ai_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `xd6w5_eaiou_ai_sessions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) NOT NULL COMMENT 'fk eaiou_papers.id',
  `session_label` varchar(255) DEFAULT NULL,
  `ai_model_name` varchar(255) NOT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `tokens_in` int(11) DEFAULT NULL,
  `tokens_out` int(11) DEFAULT NULL,
  `redaction_status` enum('none','partial','full') NOT NULL DEFAULT 'none',
  `session_notes` text DEFAULT NULL,
  `session_hash` varchar(64) DEFAULT NULL,
  `answer_box_session_id` varchar(255) DEFAULT NULL COMMENT 'SAID: Answer Box session receipt ID',
  `answer_box_ledger_capstone` varchar(255) DEFAULT NULL COMMENT 'SAID: ledger capstone for this session',
  `state` tinyint(4) NOT NULL DEFAULT 1,
  `access` int(11) NOT NULL DEFAULT 1,
  `ordering` int(11) NOT NULL DEFAULT 0,
  `created` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `checked_out` int(11) DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_paper_id` (`paper_id`),
  KEY `idx_model` (`ai_model_name`),
  KEY `idx_redaction` (`redaction_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xd6w5_eaiou_ai_sessions`
--

LOCK TABLES `xd6w5_eaiou_ai_sessions` WRITE;
/*!40000 ALTER TABLE `xd6w5_eaiou_ai_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `xd6w5_eaiou_ai_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xd6w5_eaiou_didntmakeit`
--

DROP TABLE IF EXISTS `xd6w5_eaiou_didntmakeit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `xd6w5_eaiou_didntmakeit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `session_id` int(11) NOT NULL COMMENT 'fk eaiou_ai_sessions.id',
  `prompt_text` longtext DEFAULT NULL,
  `response_text` longtext DEFAULT NULL,
  `exclusion_reason` text DEFAULT NULL,
  `redacted` tinyint(4) NOT NULL DEFAULT 0,
  `redaction_hash` varchar(64) DEFAULT NULL,
  `state` tinyint(4) NOT NULL DEFAULT 1,
  `access` int(11) NOT NULL DEFAULT 1,
  `ordering` int(11) NOT NULL DEFAULT 0,
  `created` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `checked_out` int(11) DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_session_id` (`session_id`),
  KEY `idx_redacted` (`redacted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xd6w5_eaiou_didntmakeit`
--

LOCK TABLES `xd6w5_eaiou_didntmakeit` WRITE;
/*!40000 ALTER TABLE `xd6w5_eaiou_didntmakeit` DISABLE KEYS */;
/*!40000 ALTER TABLE `xd6w5_eaiou_didntmakeit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xd6w5_eaiou_remsearch`
--

DROP TABLE IF EXISTS `xd6w5_eaiou_remsearch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `xd6w5_eaiou_remsearch` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) NOT NULL COMMENT 'fk eaiou_papers.id',
  `citation_title` varchar(500) DEFAULT NULL,
  `citation_source` varchar(255) DEFAULT NULL,
  `citation_link` varchar(1000) DEFAULT NULL,
  `source_type` enum('journal','preprint','book','dataset','code','other') DEFAULT 'journal',
  `used` tinyint(4) NOT NULL DEFAULT 0,
  `reason_unused` text DEFAULT NULL,
  `fulltext_notes` text DEFAULT NULL,
  `state` tinyint(4) NOT NULL DEFAULT 1,
  `access` int(11) NOT NULL DEFAULT 1,
  `ordering` int(11) NOT NULL DEFAULT 0,
  `created` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `checked_out` int(11) DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_paper_id` (`paper_id`),
  KEY `idx_used` (`used`),
  KEY `idx_source_type` (`source_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xd6w5_eaiou_remsearch`
--

LOCK TABLES `xd6w5_eaiou_remsearch` WRITE;
/*!40000 ALTER TABLE `xd6w5_eaiou_remsearch` DISABLE KEYS */;
/*!40000 ALTER TABLE `xd6w5_eaiou_remsearch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xd6w5_eaiou_review_logs`
--

DROP TABLE IF EXISTS `xd6w5_eaiou_review_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `xd6w5_eaiou_review_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) NOT NULL COMMENT 'fk eaiou_papers.id',
  `reviewer_id` int(11) NOT NULL COMMENT 'joomla user_id',
  `version_reviewed` varchar(100) DEFAULT NULL,
  `review_date` datetime DEFAULT NULL,
  `rubric_overall` tinyint(4) DEFAULT NULL CHECK (`rubric_overall` between 0 and 10),
  `rubric_originality` tinyint(4) DEFAULT NULL CHECK (`rubric_originality` between 0 and 10),
  `rubric_methodology` tinyint(4) DEFAULT NULL CHECK (`rubric_methodology` between 0 and 10),
  `rubric_transparency` tinyint(4) DEFAULT NULL CHECK (`rubric_transparency` between 0 and 10),
  `rubric_ai_disclosure` tinyint(4) DEFAULT NULL CHECK (`rubric_ai_disclosure` between 0 and 10),
  `rubric_crossdomain` tinyint(4) DEFAULT NULL CHECK (`rubric_crossdomain` between 0 and 10),
  `recommendation` enum('accept','minor','major','reject','abstain') DEFAULT NULL,
  `review_notes` longtext DEFAULT NULL,
  `labels_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`labels_json`)),
  `unsci_flagged` tinyint(4) NOT NULL DEFAULT 0,
  `open_consent` tinyint(4) NOT NULL DEFAULT 0,
  `state` tinyint(4) NOT NULL DEFAULT 1,
  `access` int(11) NOT NULL DEFAULT 1,
  `ordering` int(11) NOT NULL DEFAULT 0,
  `created` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `checked_out` int(11) DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_paper_id` (`paper_id`),
  KEY `idx_reviewer_id` (`reviewer_id`),
  KEY `idx_recommendation` (`recommendation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xd6w5_eaiou_review_logs`
--

LOCK TABLES `xd6w5_eaiou_review_logs` WRITE;
/*!40000 ALTER TABLE `xd6w5_eaiou_review_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `xd6w5_eaiou_review_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xd6w5_eaiou_attribution_log`
--

DROP TABLE IF EXISTS `xd6w5_eaiou_attribution_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `xd6w5_eaiou_attribution_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) NOT NULL COMMENT 'fk eaiou_papers.id',
  `contributor_name` varchar(255) NOT NULL,
  `orcid` varchar(50) DEFAULT NULL,
  `role_description` varchar(500) DEFAULT NULL,
  `contribution_type` varchar(100) DEFAULT NULL,
  `is_human` tinyint(4) NOT NULL DEFAULT 1,
  `is_ai` tinyint(4) NOT NULL DEFAULT 0,
  `ai_tool_used` varchar(255) DEFAULT NULL,
  `version_id` int(11) DEFAULT NULL COMMENT 'fk eaiou_versions.id (optional)',
  `state` tinyint(4) NOT NULL DEFAULT 1,
  `access` int(11) NOT NULL DEFAULT 1,
  `ordering` int(11) NOT NULL DEFAULT 0,
  `created` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `checked_out` int(11) DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_paper_id` (`paper_id`),
  KEY `idx_contributor` (`contributor_name`),
  KEY `idx_is_ai` (`is_ai`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xd6w5_eaiou_attribution_log`
--

LOCK TABLES `xd6w5_eaiou_attribution_log` WRITE;
/*!40000 ALTER TABLE `xd6w5_eaiou_attribution_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `xd6w5_eaiou_attribution_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xd6w5_eaiou_plugins_used`
--

DROP TABLE IF EXISTS `xd6w5_eaiou_plugins_used`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `xd6w5_eaiou_plugins_used` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) NOT NULL COMMENT 'fk eaiou_papers.id',
  `plugin_name` varchar(255) NOT NULL,
  `plugin_type` varchar(100) DEFAULT NULL,
  `execution_context` varchar(255) DEFAULT NULL,
  `exec_log_path` varchar(500) DEFAULT NULL,
  `exec_timestamp` datetime DEFAULT NULL,
  `state` tinyint(4) NOT NULL DEFAULT 1,
  `access` int(11) NOT NULL DEFAULT 1,
  `ordering` int(11) NOT NULL DEFAULT 0,
  `created` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `checked_out` int(11) DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_paper_id` (`paper_id`),
  KEY `idx_plugin_name` (`plugin_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xd6w5_eaiou_plugins_used`
--

LOCK TABLES `xd6w5_eaiou_plugins_used` WRITE;
/*!40000 ALTER TABLE `xd6w5_eaiou_plugins_used` DISABLE KEYS */;
/*!40000 ALTER TABLE `xd6w5_eaiou_plugins_used` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xd6w5_eaiou_api_keys`
--

DROP TABLE IF EXISTS `xd6w5_eaiou_api_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `xd6w5_eaiou_api_keys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT 'joomla user_id',
  `api_key` varchar(255) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `access_level` enum('read','submit','review','admin') NOT NULL DEFAULT 'read',
  `status` enum('active','revoked','suspended') NOT NULL DEFAULT 'active',
  `last_used` datetime DEFAULT NULL,
  `state` tinyint(4) NOT NULL DEFAULT 1,
  `access` int(11) NOT NULL DEFAULT 1,
  `ordering` int(11) NOT NULL DEFAULT 0,
  `created` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `checked_out` int(11) DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_key` (`api_key`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_access_level` (`access_level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xd6w5_eaiou_api_keys`
--

LOCK TABLES `xd6w5_eaiou_api_keys` WRITE;
/*!40000 ALTER TABLE `xd6w5_eaiou_api_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `xd6w5_eaiou_api_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xd6w5_eaiou_api_logs`
--

DROP TABLE IF EXISTS `xd6w5_eaiou_api_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `xd6w5_eaiou_api_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `api_key_id` int(11) NOT NULL COMMENT 'fk eaiou_api_keys.id',
  `endpoint` varchar(500) NOT NULL,
  `method` varchar(10) DEFAULT NULL,
  `request_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`request_data`)),
  `response_code` smallint(6) DEFAULT NULL,
  `log_hash` varchar(64) DEFAULT NULL COMMENT 'SHA256 of this record — tamper detection',
  `prior_hash` varchar(64) DEFAULT NULL COMMENT 'SHA256 of previous log entry — chain integrity',
  `log_timestamp` datetime NOT NULL,
  `state` tinyint(4) NOT NULL DEFAULT 1,
  `access` int(11) NOT NULL DEFAULT 1,
  `ordering` int(11) NOT NULL DEFAULT 0,
  `created` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `checked_out` int(11) DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_api_key_id` (`api_key_id`),
  KEY `idx_endpoint` (`endpoint`(100)),
  KEY `idx_timestamp` (`log_timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xd6w5_eaiou_api_logs`
--

LOCK TABLES `xd6w5_eaiou_api_logs` WRITE;
/*!40000 ALTER TABLE `xd6w5_eaiou_api_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `xd6w5_eaiou_api_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xd6w5_eaiou_quality_signals`
--

DROP TABLE IF EXISTS `xd6w5_eaiou_quality_signals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `xd6w5_eaiou_quality_signals` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) NOT NULL COMMENT 'fk eaiou_papers.id',
  `review_log_id` int(11) DEFAULT NULL COMMENT 'fk eaiou_review_logs.id',
  `q_overall` decimal(5,3) DEFAULT NULL,
  `q_originality` decimal(5,3) DEFAULT NULL,
  `q_methodology` decimal(5,3) DEFAULT NULL,
  `q_transparency` decimal(5,3) DEFAULT NULL COMMENT 'weighted 1.5x in q_signal — AI disclosure quality is privileged',
  `q_ai_disclosure` decimal(5,3) DEFAULT NULL,
  `q_crossdomain` decimal(5,3) DEFAULT NULL,
  `q_signal` decimal(7,4) DEFAULT NULL COMMENT 'computed composite — the discovery sort key',
  `weight_override` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'per-computation weight overrides if any' CHECK (json_valid(`weight_override`)),
  `computed_at` datetime DEFAULT NULL,
  `state` tinyint(4) NOT NULL DEFAULT 1,
  `access` int(11) NOT NULL DEFAULT 1,
  `ordering` int(11) NOT NULL DEFAULT 0,
  `created` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `checked_out` int(11) DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_paper_id` (`paper_id`),
  KEY `idx_q_signal` (`q_signal`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xd6w5_eaiou_quality_signals`
--

LOCK TABLES `xd6w5_eaiou_quality_signals` WRITE;
/*!40000 ALTER TABLE `xd6w5_eaiou_quality_signals` DISABLE KEYS */;
/*!40000 ALTER TABLE `xd6w5_eaiou_quality_signals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xd6w5_categories`
--

DROP TABLE IF EXISTS `xd6w5_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `xd6w5_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'FK to the #__assets table.',
  `parent_id` int(10) unsigned NOT NULL DEFAULT 0,
  `lft` int(11) NOT NULL DEFAULT 0,
  `rgt` int(11) NOT NULL DEFAULT 0,
  `level` int(10) unsigned NOT NULL DEFAULT 0,
  `path` varchar(400) NOT NULL DEFAULT '',
  `extension` varchar(50) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `description` mediumtext DEFAULT NULL,
  `published` tinyint(4) NOT NULL DEFAULT 0,
  `checked_out` int(10) unsigned DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  `access` int(10) unsigned NOT NULL DEFAULT 0,
  `params` text DEFAULT NULL,
  `metadesc` varchar(1024) NOT NULL DEFAULT '' COMMENT 'The meta description for the page.',
  `metakey` varchar(1024) NOT NULL DEFAULT '' COMMENT 'The keywords for the page.',
  `metadata` varchar(2048) NOT NULL DEFAULT '' COMMENT 'JSON encoded metadata properties.',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `created_time` datetime NOT NULL,
  `modified_user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `modified_time` datetime NOT NULL,
  `hits` int(10) unsigned NOT NULL DEFAULT 0,
  `language` char(7) NOT NULL DEFAULT '',
  `version` int(10) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `cat_idx` (`extension`,`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_path` (`path`(100)),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`(100)),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xd6w5_categories`
--

LOCK TABLES `xd6w5_categories` WRITE;
/*!40000 ALTER TABLE `xd6w5_categories` DISABLE KEYS */;
INSERT INTO `xd6w5_categories` VALUES
(1,0,0,0,11,0,'','system','ROOT','root','','',1,NULL,NULL,1,'{}','','','{}',170,'2026-04-07 08:51:06',170,'2026-04-07 08:51:06',0,'*',1),
(2,27,1,19,20,1,'uncategorised','com_content','Uncategorised','uncategorised','','',1,NULL,NULL,1,'{\"category_layout\":\"\",\"image\":\"\",\"workflow_id\":\"use_default\"}','','','{\"author\":\"\",\"robots\":\"\"}',170,'2026-04-07 08:51:06',170,'2026-04-07 08:51:06',0,'*',1),
(3,28,1,3,4,1,'uncategorised','com_banners','Uncategorised','uncategorised','','',1,NULL,NULL,1,'{\"category_layout\":\"\",\"image\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',170,'2026-04-07 08:51:06',170,'2026-04-07 08:51:06',0,'*',1),
(4,29,1,5,6,1,'uncategorised','com_contact','Uncategorised','uncategorised','','',1,NULL,NULL,1,'{\"category_layout\":\"\",\"image\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',170,'2026-04-07 08:51:06',170,'2026-04-07 08:51:06',0,'*',1),
(5,30,1,7,8,1,'uncategorised','com_newsfeeds','Uncategorised','uncategorised','','',1,NULL,NULL,1,'{\"category_layout\":\"\",\"image\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',170,'2026-04-07 08:51:06',170,'2026-04-07 08:51:06',0,'*',1),
(7,32,1,9,10,1,'uncategorised','com_users','Uncategorised','uncategorised','','',1,NULL,NULL,1,'{\"category_layout\":\"\",\"image\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',170,'2026-04-07 08:51:06',170,'2026-04-07 08:51:06',0,'*',1),
(8,0,1,21,22,1,'uncategorised','com_content','Uncategorised','uncategorised','','',1,NULL,NULL,1,'{}','','','{}',42,'2026-04-07 10:33:34',0,'2026-04-07 10:33:34',0,'*',1),
(9,0,1,1,18,1,'eaiou-papers','com_content','eaiou Papers','eaiou-papers','','eaiou peer-reviewed journal — all disciplines. Ordered by q_signal, not by time.',1,NULL,NULL,1,'{}','eaiou peer-reviewed journal — all disciplines. Ordered by q_signal, not by time.','','{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}',42,'2026-04-07 13:15:29',0,'2026-04-07 13:15:29',0,'*',1),
(10,0,9,6,7,2,'eaiou-papers/eaiou-mathematics','com_content','Mathematics & Algebra','eaiou-mathematics','','N/U Algebra, U/N Algebra, formal systems',1,NULL,NULL,1,'{}','N/U Algebra, U/N Algebra, formal systems','','{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}',42,'2026-04-07 13:15:29',0,'2026-04-07 13:15:29',0,'*',1),
(11,0,9,16,17,2,'eaiou-papers/eaiou-physics','com_content','Physics & Cosmology','eaiou-physics','','Hubble tension, cosmological models, dark energy',1,NULL,NULL,1,'{}','Hubble tension, cosmological models, dark energy','','{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}',42,'2026-04-07 13:15:29',0,'2026-04-07 13:15:29',0,'*',1),
(12,0,9,2,3,2,'eaiou-papers/eaiou-cs-ai','com_content','Computer Science & AI','eaiou-cs-ai','','Artificial intelligence, algorithms, observer systems',1,NULL,NULL,1,'{}','Artificial intelligence, algorithms, observer systems','','{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}',42,'2026-04-07 13:15:29',0,'2026-04-07 13:15:29',0,'*',1),
(13,0,9,4,5,2,'eaiou-papers/eaiou-cross-domain','com_content','Cross-Domain Research','eaiou-cross-domain','','Research that bridges multiple disciplines',1,NULL,NULL,1,'{}','Research that bridges multiple disciplines','','{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}',42,'2026-04-07 13:15:29',0,'2026-04-07 13:15:29',0,'*',1),
(14,0,9,12,13,2,'eaiou-papers/eaiou-observer-theory','com_content','Observer Theory','eaiou-observer-theory','','OMMP, UHA, observer-preserving frameworks',1,NULL,NULL,1,'{}','OMMP, UHA, observer-preserving frameworks','','{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}',42,'2026-04-07 13:15:29',0,'2026-04-07 13:15:29',0,'*',1),
(15,0,9,8,9,2,'eaiou-papers/eaiou-methodology','com_content','Methodology & Transparency','eaiou-methodology','','Research methods, reproducibility, AI disclosure',1,NULL,NULL,1,'{}','Research methods, reproducibility, AI disclosure','','{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}',42,'2026-04-07 13:15:29',0,'2026-04-07 13:15:29',0,'*',1),
(16,0,9,14,15,2,'eaiou-papers/eaiou-open-questions','com_content','Open Questions','eaiou-open-questions','','Exploratory, speculative, and stalled research',1,NULL,NULL,1,'{}','Exploratory, speculative, and stalled research','','{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}',42,'2026-04-07 13:15:29',0,'2026-04-07 13:15:29',0,'*',1),
(17,0,9,10,11,2,'eaiou-papers/eaiou-null-results','com_content','Null & Negative Results','eaiou-null-results','','Null, negative, and replication results',1,NULL,NULL,1,'{}','Null, negative, and replication results','','{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}',42,'2026-04-07 13:15:29',0,'2026-04-07 13:15:29',0,'*',1);
/*!40000 ALTER TABLE `xd6w5_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xd6w5_usergroups`
--

DROP TABLE IF EXISTS `xd6w5_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `xd6w5_usergroups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `parent_id` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'Adjacency List Reference Id',
  `lft` int(11) NOT NULL DEFAULT 0 COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT 0 COMMENT 'Nested set rgt.',
  `title` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_usergroup_parent_title_lookup` (`parent_id`,`title`),
  KEY `idx_usergroup_title_lookup` (`title`),
  KEY `idx_usergroup_adjacency_lookup` (`parent_id`),
  KEY `idx_usergroup_nested_set_lookup` (`lft`,`rgt`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xd6w5_usergroups`
--

LOCK TABLES `xd6w5_usergroups` WRITE;
/*!40000 ALTER TABLE `xd6w5_usergroups` DISABLE KEYS */;
INSERT INTO `xd6w5_usergroups` VALUES
(1,0,1,30,'Public'),
(2,1,10,27,'Registered'),
(3,2,11,16,'Author'),
(4,3,12,15,'Editor'),
(5,4,13,14,'Publisher'),
(6,1,4,9,'Manager'),
(7,6,5,8,'Administrator'),
(8,1,28,29,'Super Users'),
(9,1,2,3,'Guest'),
(10,2,19,20,'eaiou_Author'),
(11,2,21,26,'eaiou_Reviewer'),
(12,2,17,18,'eaiou_APIClient'),
(13,7,6,7,'eaiou_Admin'),
(14,11,22,25,'eaiou_Editor'),
(15,14,23,24,'eaiou_EIC');
/*!40000 ALTER TABLE `xd6w5_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xd6w5_viewlevels`
--

DROP TABLE IF EXISTS `xd6w5_viewlevels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `xd6w5_viewlevels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `title` varchar(100) NOT NULL DEFAULT '',
  `ordering` int(11) NOT NULL DEFAULT 0,
  `rules` varchar(5120) NOT NULL COMMENT 'JSON encoded access control.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_assetgroup_title_lookup` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xd6w5_viewlevels`
--

LOCK TABLES `xd6w5_viewlevels` WRITE;
/*!40000 ALTER TABLE `xd6w5_viewlevels` DISABLE KEYS */;
INSERT INTO `xd6w5_viewlevels` VALUES
(1,'Public',0,'[1]'),
(2,'Registered',2,'[6,2,8]'),
(3,'Special',3,'[6,3,8]'),
(5,'Guest',1,'[9]'),
(6,'Super Users',4,'[8]');
/*!40000 ALTER TABLE `xd6w5_viewlevels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xd6w5_content`
--

DROP TABLE IF EXISTS `xd6w5_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `xd6w5_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'FK to the #__assets table.',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `introtext` mediumtext NOT NULL,
  `fulltext` mediumtext NOT NULL,
  `state` tinyint(4) NOT NULL DEFAULT 0,
  `catid` int(10) unsigned NOT NULL DEFAULT 0,
  `created` datetime NOT NULL,
  `created_by` int(10) unsigned NOT NULL DEFAULT 0,
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL,
  `modified_by` int(10) unsigned NOT NULL DEFAULT 0,
  `checked_out` int(10) unsigned DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  `publish_up` datetime DEFAULT NULL,
  `publish_down` datetime DEFAULT NULL,
  `images` text NOT NULL,
  `urls` text NOT NULL,
  `attribs` varchar(5120) NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT 1,
  `ordering` int(11) NOT NULL DEFAULT 0,
  `metakey` text DEFAULT NULL,
  `metadesc` text NOT NULL,
  `access` int(10) unsigned NOT NULL DEFAULT 0,
  `hits` int(10) unsigned NOT NULL DEFAULT 0,
  `metadata` text NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT 0 COMMENT 'Set if article is featured.',
  `language` char(7) NOT NULL COMMENT 'The language code for the article.',
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`state`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_alias` (`alias`(191))
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xd6w5_content`
--

LOCK TABLES `xd6w5_content` WRITE;
/*!40000 ALTER TABLE `xd6w5_content` DISABLE KEYS */;
INSERT INTO `xd6w5_content` VALUES
(1,0,'What is eaiou?','what-is-eaiou','<p>eaiou is a research discovery platform built on a single doctrine: <strong>you do not read science by time.</strong></p><p>The truth does not have a timestamp. The physics does not expire. A result is correct or incorrect independent of when it was written.</p><p>Most platforms surface work by date — newest first. That is a filing system, not a discovery engine. Recency becomes a credibility signal it was never meant to be. Researchers race to publish. Foundational work gets buried under newer noise.</p><p>eaiou is built differently.</p>','<h2>How It Works</h2><p>Submission dates on eaiou are <strong>sealed state space</strong>. At submission, the date is captured, hashed with the paper content, and anchored to an external immutable record (Zenodo). Justice has access. Bias does not.</p><p>The public surface shows the <strong>work itself</strong> — ordered by content relevance, editorial quality, and cross-domain applicability. Never by when it arrived.</p><h2>Who It Is For</h2><p>Researchers who do the work because the work is true, not because the clock is running. Readers who want the best answer to a question, not the most recent one. Reviewers who evaluate ideas on internal logic, not age.</p><h2>The Sealed Date</h2><p>At submission, three things happen simultaneously: the timestamp is stored encrypted, a SHA-256 hash binds the content to that moment, and a Zenodo capstone anchors the hash externally. The capstone is perpetual.</p><h2>The Principle</h2><blockquote><em>The ground state was there before the observational plane was occupied. Submission date is movement. The paper is vibration. The truth precedes both.</em><br>— Eric D. Martin, ORCID: 0009-0006-5944-1742</blockquote>',1,2,'2026-04-07 10:35:16',42,'','2026-04-07 10:35:16',0,NULL,NULL,NULL,NULL,'{}','{}','{}',1,1,'research discovery, temporal blindness, science platform','eaiou is a research discovery platform where papers are surfaced by quality and content, never by submission date.',1,2,'{}',1,'*',''),
(2,0,'Discover Ideas','discover-ideas','Emerging ideas from unused datasets, ranked by entropy-novelty. Coming soon.','',1,2,'2026-04-07 15:22:24',170,'','2026-04-07 15:22:24',170,NULL,NULL,NULL,NULL,'{}','{}','{}',1,0,'','',1,0,'{}',0,'*',''),
(3,0,'Open Research','discover-open','Papers open to collaboration, with type and interest level. Coming soon.','',1,2,'2026-04-07 15:22:24',170,'','2026-04-07 15:22:24',170,NULL,NULL,NULL,NULL,'{}','{}','{}',1,0,'','',1,0,'{}',0,'*',''),
(4,0,'Research Gaps','discover-gaps','Gap map — where research keeps stalling, by domain. Coming soon.','',1,2,'2026-04-07 15:22:24',170,'','2026-04-07 15:22:24',170,NULL,NULL,NULL,NULL,'{}','{}','{}',1,0,'','',1,0,'{}',0,'*',''),
(5,0,'Trends','discover-trends','Trend and insight surface across the journal. Coming soon.','',1,2,'2026-04-07 15:22:24',170,'','2026-04-07 15:22:24',170,NULL,NULL,NULL,NULL,'{}','{}','{}',1,0,'','',1,0,'{}',0,'*',''),
(6,0,'Submit a Paper','submit','Multi-step submission wizard. Authors only. Coming soon.','',1,2,'2026-04-07 15:22:24',170,'','2026-04-07 15:22:24',170,NULL,NULL,NULL,NULL,'{}','{}','{}',1,0,'','',1,0,'{}',0,'*',''),
(7,0,'My Papers','mypapers','Your submissions and current workflow state. Authors only. Coming soon.','',1,2,'2026-04-07 15:22:24',170,'','2026-04-07 15:22:24',170,NULL,NULL,NULL,NULL,'{}','{}','{}',1,0,'','',1,0,'{}',0,'*',''),
(8,0,'Reviewer Queue','reviewer-queue','Papers assigned for review. Reviewers only. Coming soon.','',1,2,'2026-04-07 15:22:24',170,'','2026-04-07 15:22:24',170,NULL,NULL,NULL,NULL,'{}','{}','{}',1,0,'','',1,0,'{}',0,'*',''),
(9,0,'Editorial Dashboard','editorial-papers','All papers in all workflow states. Editors only. Coming soon.','',1,2,'2026-04-07 15:22:24',170,'','2026-04-07 15:22:24',170,NULL,NULL,NULL,NULL,'{}','{}','{}',1,0,'','',1,0,'{}',0,'*',''),
(10,0,'About eaiou','about','eaiou is an observer-preserving, full-context peer-review journal. Quality is the only sort key. Submission dates are sealed.','',1,2,'2026-04-07 15:22:24',170,'','2026-04-07 15:22:24',170,NULL,NULL,NULL,NULL,'{}','{}','{}',1,0,'','',1,0,'{}',0,'*','');
/*!40000 ALTER TABLE `xd6w5_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xd6w5_menu`
--

DROP TABLE IF EXISTS `xd6w5_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `xd6w5_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menutype` varchar(24) NOT NULL COMMENT 'The type of menu this item belongs to. FK to #__menu_types.menutype',
  `title` varchar(255) NOT NULL COMMENT 'The display title of the menu item.',
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'The SEF alias of the menu item.',
  `note` varchar(255) NOT NULL DEFAULT '',
  `path` varchar(1024) NOT NULL COMMENT 'The computed path of the menu item based on the alias field.',
  `link` varchar(1024) NOT NULL COMMENT 'The actually link the menu item refers to.',
  `type` varchar(16) NOT NULL COMMENT 'The type of link: Component, URL, Alias, Separator',
  `published` tinyint(4) NOT NULL DEFAULT 0 COMMENT 'The published state of the menu link.',
  `parent_id` int(10) unsigned NOT NULL DEFAULT 1 COMMENT 'The parent menu item in the menu tree.',
  `level` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'The relative level in the tree.',
  `component_id` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'FK to #__extensions.id',
  `checked_out` int(10) unsigned DEFAULT NULL COMMENT 'FK to #__users.id',
  `checked_out_time` datetime DEFAULT NULL COMMENT 'The time the menu item was checked out.',
  `browserNav` tinyint(4) NOT NULL DEFAULT 0 COMMENT 'The click behaviour of the link.',
  `access` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'The access level required to view the menu item.',
  `img` varchar(255) NOT NULL COMMENT 'The image of the menu item.',
  `template_style_id` int(10) unsigned NOT NULL DEFAULT 0,
  `params` text NOT NULL COMMENT 'JSON encoded data for the menu item.',
  `lft` int(11) NOT NULL DEFAULT 0 COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT 0 COMMENT 'Nested set rgt.',
  `home` tinyint(3) unsigned NOT NULL DEFAULT 0 COMMENT 'Indicates if this menu item is the home or default page.',
  `language` char(7) NOT NULL DEFAULT '',
  `client_id` tinyint(4) NOT NULL DEFAULT 0,
  `publish_up` datetime DEFAULT NULL,
  `publish_down` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_client_id_parent_id_alias_language` (`client_id`,`parent_id`,`alias`(100),`language`),
  KEY `idx_componentid` (`component_id`,`menutype`,`published`,`access`),
  KEY `idx_menutype` (`menutype`),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`(100)),
  KEY `idx_path` (`path`(100)),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB AUTO_INCREMENT=205 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xd6w5_menu`
--

LOCK TABLES `xd6w5_menu` WRITE;
/*!40000 ALTER TABLE `xd6w5_menu` DISABLE KEYS */;
INSERT INTO `xd6w5_menu` VALUES
(1,'','Menu_Item_Root','root','','','','',1,0,0,0,NULL,NULL,0,0,'',0,'',1,23,0,'*',0,NULL,NULL),
(2,'main','com_banners','Banners','','Banners','index.php?option=com_banners','component',1,1,1,3,NULL,NULL,0,0,'class:bookmark',0,'',1,10,0,'*',1,NULL,NULL),
(3,'main','com_banners','Banners','','Banners/Banners','index.php?option=com_banners&view=banners','component',1,2,2,3,NULL,NULL,0,0,'class:banners',0,'',2,3,0,'*',1,NULL,NULL),
(4,'main','com_banners_categories','Categories','','Banners/Categories','index.php?option=com_categories&view=categories&extension=com_banners','component',1,2,2,5,NULL,NULL,0,0,'class:banners-cat',0,'',4,5,0,'*',1,NULL,NULL),
(5,'main','com_banners_clients','Clients','','Banners/Clients','index.php?option=com_banners&view=clients','component',1,2,2,3,NULL,NULL,0,0,'class:banners-clients',0,'',6,7,0,'*',1,NULL,NULL),
(6,'main','com_banners_tracks','Tracks','','Banners/Tracks','index.php?option=com_banners&view=tracks','component',1,2,2,3,NULL,NULL,0,0,'class:banners-tracks',0,'',8,9,0,'*',1,NULL,NULL),
(7,'main','com_contact','Contacts','','Contacts','index.php?option=com_contact','component',1,1,1,7,NULL,NULL,0,0,'class:address-book',0,'',11,20,0,'*',1,NULL,NULL),
(8,'main','com_contact_contacts','Contacts','','Contacts/Contacts','index.php?option=com_contact&view=contacts','component',1,7,2,7,NULL,NULL,0,0,'class:contact',0,'',12,13,0,'*',1,NULL,NULL),
(9,'main','com_contact_categories','Categories','','Contacts/Categories','index.php?option=com_categories&view=categories&extension=com_contact','component',1,7,2,5,NULL,NULL,0,0,'class:contact-cat',0,'',14,15,0,'*',1,NULL,NULL),
(10,'main','com_newsfeeds','News Feeds','','News Feeds','index.php?option=com_newsfeeds','component',1,1,1,16,NULL,NULL,0,0,'class:rss',0,'',23,28,0,'*',1,NULL,NULL),
(11,'main','com_newsfeeds_feeds','Feeds','','News Feeds/Feeds','index.php?option=com_newsfeeds&view=newsfeeds','component',1,10,2,16,NULL,NULL,0,0,'class:newsfeeds',0,'',24,25,0,'*',1,NULL,NULL),
(12,'main','com_newsfeeds_categories','Categories','','News Feeds/Categories','index.php?option=com_categories&view=categories&extension=com_newsfeeds','component',1,10,2,5,NULL,NULL,0,0,'class:newsfeeds-cat',0,'',26,27,0,'*',1,NULL,NULL),
(13,'main','com_finder','Smart Search','','Smart Search','index.php?option=com_finder','component',1,1,1,23,NULL,NULL,0,0,'class:search-plus',0,'',29,38,0,'*',1,NULL,NULL),
(14,'main','com_tags','Tags','','Tags','index.php?option=com_tags&view=tags','component',1,1,1,25,NULL,NULL,0,1,'class:tags',0,'',39,40,0,'',1,NULL,NULL),
(15,'main','com_associations','Multilingual Associations','','Multilingual Associations','index.php?option=com_associations&view=associations','component',1,1,1,30,NULL,NULL,0,0,'class:language',0,'',21,22,0,'*',1,NULL,NULL),
(16,'main','mod_menu_fields','Contact Custom Fields','','Contacts/Contact Custom Fields','index.php?option=com_fields&context=com_contact.contact','component',1,7,2,29,NULL,NULL,0,0,'class:messages-add',0,'',16,17,0,'*',1,NULL,NULL),
(17,'main','mod_menu_fields_group','Contact Custom Fields Group','','Contacts/Contact Custom Fields Group','index.php?option=com_fields&view=groups&context=com_contact.contact','component',1,7,2,29,NULL,NULL,0,0,'class:messages-add',0,'',18,19,0,'*',1,NULL,NULL),
(18,'main','com_finder_index','Smart-Search-Index','','Smart Search/Smart-Search-Index','index.php?option=com_finder&view=index','component',1,13,2,23,NULL,NULL,0,0,'class:finder',0,'',30,31,0,'*',1,NULL,NULL),
(19,'main','com_finder_maps','Smart-Search-Maps','','Smart Search/Smart-Search-Maps','index.php?option=com_finder&view=maps','component',1,13,2,23,NULL,NULL,0,0,'class:finder-maps',0,'',32,33,0,'*',1,NULL,NULL),
(20,'main','com_finder_filters','Smart-Search-Filters','','Smart Search/Smart-Search-Filters','index.php?option=com_finder&view=filters','component',1,13,2,23,NULL,NULL,0,0,'class:finder-filters',0,'',34,35,0,'*',1,NULL,NULL),
(21,'main','com_finder_searches','Smart-Search-Searches','','Smart Search/Smart-Search-Searches','index.php?option=com_finder&view=searches','component',1,13,2,23,NULL,NULL,0,0,'class:finder-searches',0,'',36,37,0,'*',1,NULL,NULL),
(101,'mainmenu','Home','home','','home','index.php?option=com_content&view=featured','component',1,1,1,19,NULL,NULL,0,1,'',0,'{\"featured_categories\":[\"\"],\"layout_type\":\"blog\",\"blog_class_leading\":\"\",\"blog_class\":\"\",\"num_leading_articles\":\"1\",\"num_intro_articles\":\"3\",\"num_links\":\"0\",\"link_intro_image\":\"\",\"orderby_pri\":\"\",\"orderby_sec\":\"front\",\"order_date\":\"\",\"show_pagination\":\"2\",\"show_pagination_results\":\"1\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"info_block_show_title\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_associations\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_readmore\":\"\",\"show_readmore_title\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"show_feed_link\":\"1\",\"feed_summary\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_image_css\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"1\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"robots\":\"\"}',1,2,1,'*',0,NULL,NULL),
(126,'main','com_rsseo','com-rsseo','','com-rsseo','index.php?option=com_rsseo','component',1,1,1,253,NULL,NULL,0,1,'class:component',0,'{}',43,74,0,'',1,NULL,NULL),
(127,'main','COM_RSSEO_MENU_OVERVIEW','com-rsseo-menu-overview','','com-rsseo/com-rsseo-menu-overview','index.php?option=com_rsseo','component',1,126,2,253,NULL,NULL,0,1,'class:component',0,'{}',44,45,0,'',1,NULL,NULL),
(128,'main','COM_RSSEO_MENU_PAGES','com-rsseo-menu-pages','','com-rsseo/com-rsseo-menu-pages','index.php?option=com_rsseo&view=pages','component',1,126,2,253,NULL,NULL,0,1,'class:component',0,'{}',46,47,0,'',1,NULL,NULL),
(129,'main','COM_RSSEO_MENU_CRAWLER','com-rsseo-menu-crawler','','com-rsseo/com-rsseo-menu-crawler','index.php?option=com_rsseo&view=crawler','component',1,126,2,253,NULL,NULL,0,1,'class:component',0,'{}',48,49,0,'',1,NULL,NULL),
(130,'main','COM_RSSEO_MENU_SITEMAP','com-rsseo-menu-sitemap','','com-rsseo/com-rsseo-menu-sitemap','index.php?option=com_rsseo&view=sitemap','component',1,126,2,253,NULL,NULL,0,1,'class:component',0,'{}',50,51,0,'',1,NULL,NULL),
(131,'main','COM_RSSEO_MENU_ROBOTS','com-rsseo-menu-robots','','com-rsseo/com-rsseo-menu-robots','index.php?option=com_rsseo&view=robots','component',1,126,2,253,NULL,NULL,0,1,'class:component',0,'{}',52,53,0,'',1,NULL,NULL),
(132,'main','COM_RSSEO_MENU_ERRORS','com-rsseo-menu-errors','','com-rsseo/com-rsseo-menu-errors','index.php?option=com_rsseo&view=errors','component',1,126,2,253,NULL,NULL,0,1,'class:component',0,'{}',54,55,0,'',1,NULL,NULL),
(133,'main','COM_RSSEO_MENU_ERROR_LINKS','com-rsseo-menu-error-links','','com-rsseo/com-rsseo-menu-error-links','index.php?option=com_rsseo&view=errorlinks','component',1,126,2,253,NULL,NULL,0,1,'class:component',0,'{}',56,57,0,'',1,NULL,NULL),
(134,'main','COM_RSSEO_MENU_REDIRECTS','com-rsseo-menu-redirects','','com-rsseo/com-rsseo-menu-redirects','index.php?option=com_rsseo&view=redirects','component',1,126,2,253,NULL,NULL,0,1,'class:component',0,'{}',58,59,0,'',1,NULL,NULL),
(135,'main','COM_RSSEO_MENU_KEYWORDS','com-rsseo-menu-keywords','','com-rsseo/com-rsseo-menu-keywords','index.php?option=com_rsseo&view=keywords','component',1,126,2,253,NULL,NULL,0,1,'class:component',0,'{}',60,61,0,'',1,NULL,NULL),
(136,'main','COM_RSSEO_MENU_GKEYWORDS','com-rsseo-menu-gkeywords','','com-rsseo/com-rsseo-menu-gkeywords','index.php?option=com_rsseo&view=gkeywords','component',1,126,2,253,NULL,NULL,0,1,'class:component',0,'{}',62,63,0,'',1,NULL,NULL),
(137,'main','COM_RSSEO_MENU_GAANALYTICS','com-rsseo-menu-gaanalytics','','com-rsseo/com-rsseo-menu-gaanalytics','index.php?option=com_rsseo&view=analytics','component',1,126,2,253,NULL,NULL,0,1,'class:component',0,'{}',64,65,0,'',1,NULL,NULL),
(138,'main','COM_RSSEO_MENU_STRUCTURED_DATA','com-rsseo-menu-structured-data','','com-rsseo/com-rsseo-menu-structured-data','index.php?option=com_rsseo&view=data','component',1,126,2,253,NULL,NULL,0,1,'class:component',0,'{}',66,67,0,'',1,NULL,NULL),
(139,'main','COM_RSSEO_MENU_STATISTICS','com-rsseo-menu-statistics','','com-rsseo/com-rsseo-menu-statistics','index.php?option=com_rsseo&view=statistics','component',1,126,2,253,NULL,NULL,0,1,'class:component',0,'{}',68,69,0,'',1,NULL,NULL),
(140,'main','COM_RSSEO_MENU_REPORT','com-rsseo-menu-report','','com-rsseo/com-rsseo-menu-report','index.php?option=com_rsseo&view=report','component',1,126,2,253,NULL,NULL,0,1,'class:component',0,'{}',70,71,0,'',1,NULL,NULL),
(141,'main','COM_RSSEO_MENU_BACKUPRESTORE','com-rsseo-menu-backuprestore','','com-rsseo/com-rsseo-menu-backuprestore','index.php?option=com_rsseo&view=backup','component',1,126,2,253,NULL,NULL,0,1,'class:component',0,'{}',72,73,0,'',1,NULL,NULL),
(142,'main','COM_JCE','com-jce','','com-jce','index.php?option=com_jce&view=cpanel','component',1,1,1,258,NULL,NULL,0,1,'class:component',0,'{}',75,84,0,'',1,NULL,NULL),
(143,'main','COM_JCE_MENU_CPANEL','com-jce-menu-cpanel','','com-jce/com-jce-menu-cpanel','index.php?option=com_jce&view=cpanel','component',1,142,2,258,NULL,NULL,0,1,'class:component',0,'{}',76,77,0,'',1,NULL,NULL),
(144,'main','COM_JCE_MENU_CONFIG','com-jce-menu-config','','com-jce/com-jce-menu-config','index.php?option=com_jce&view=config','component',1,142,2,258,NULL,NULL,0,1,'class:component',0,'{}',78,79,0,'',1,NULL,NULL),
(145,'main','COM_JCE_MENU_PROFILES','com-jce-menu-profiles','','com-jce/com-jce-menu-profiles','index.php?option=com_jce&view=profiles','component',1,142,2,258,NULL,NULL,0,1,'class:component',0,'{}',80,81,0,'',1,NULL,NULL),
(146,'main','COM_JCE_MENU_FILEBROWSER','com-jce-menu-filebrowser','','com-jce/com-jce-menu-filebrowser','index.php?option=com_jce&view=browser','component',1,142,2,258,NULL,NULL,0,1,'class:component',0,'{}',82,83,0,'',1,NULL,NULL),
(195,'mainmenu','Discover','discover','','discover','','heading',1,1,1,0,0,NULL,0,1,'',0,'{}',3,12,0,'*',0,NULL,NULL),
(196,'mainmenu','Papers','papers','','papers','index.php?option=com_content&view=category&layout=blog&id=9','component',1,1,1,19,0,NULL,0,1,'',0,'{}',13,14,0,'*',0,NULL,NULL),
(197,'mainmenu','Search','search','','search','index.php?option=com_finder&view=search','component',1,1,1,23,0,NULL,0,1,'',0,'{}',15,16,0,'*',0,NULL,NULL),
(198,'mainmenu','Submit','submit-m','','submit-paper','index.php?option=com_content&view=article&id=6','component',1,1,1,19,0,NULL,0,1,'',0,'{}',17,18,0,'*',0,NULL,NULL),
(199,'mainmenu','My Papers','mypapers-m','','my-papers','index.php?option=com_content&view=article&id=7','component',1,1,1,19,0,NULL,0,3,'',0,'{}',19,20,0,'*',0,NULL,NULL),
(200,'mainmenu','About','about-m','','about-eaiou','index.php?option=com_content&view=article&id=10','component',1,1,1,19,0,NULL,0,1,'',0,'{}',21,22,0,'*',0,NULL,NULL),
(201,'mainmenu','Ideas','d-ideas','','discover/ideas','index.php?option=com_content&view=article&id=2','component',1,195,2,19,0,NULL,0,1,'',0,'{}',4,5,0,'*',0,NULL,NULL),
(202,'mainmenu','Open Research','d-open','','discover/open','index.php?option=com_content&view=article&id=3','component',1,195,2,19,0,NULL,0,1,'',0,'{}',6,7,0,'*',0,NULL,NULL),
(203,'mainmenu','Research Gaps','d-gaps','','discover/gaps','index.php?option=com_content&view=article&id=4','component',1,195,2,19,0,NULL,0,1,'',0,'{}',8,9,0,'*',0,NULL,NULL),
(204,'mainmenu','Trends','d-trends','','discover/trends','index.php?option=com_content&view=article&id=5','component',1,195,2,19,0,NULL,0,1,'',0,'{}',10,11,0,'*',0,NULL,NULL);
/*!40000 ALTER TABLE `xd6w5_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xd6w5_menu_types`
--

DROP TABLE IF EXISTS `xd6w5_menu_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `xd6w5_menu_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT 0,
  `menutype` varchar(24) NOT NULL,
  `title` varchar(48) NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `client_id` int(11) NOT NULL DEFAULT 0,
  `ordering` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_menutype` (`menutype`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xd6w5_menu_types`
--

LOCK TABLES `xd6w5_menu_types` WRITE;
/*!40000 ALTER TABLE `xd6w5_menu_types` DISABLE KEYS */;
INSERT INTO `xd6w5_menu_types` VALUES
(1,0,'mainmenu','Main Menu','The main menu for the site',0,1);
/*!40000 ALTER TABLE `xd6w5_menu_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xd6w5_workflows`
--

DROP TABLE IF EXISTS `xd6w5_workflows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `xd6w5_workflows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) DEFAULT 0,
  `published` tinyint(4) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `extension` varchar(50) NOT NULL,
  `default` tinyint(4) NOT NULL DEFAULT 0,
  `ordering` int(11) NOT NULL DEFAULT 0,
  `created` datetime NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `modified` datetime NOT NULL,
  `modified_by` int(11) NOT NULL DEFAULT 0,
  `checked_out_time` datetime DEFAULT NULL,
  `checked_out` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_asset_id` (`asset_id`),
  KEY `idx_title` (`title`(191)),
  KEY `idx_extension` (`extension`),
  KEY `idx_default` (`default`),
  KEY `idx_created` (`created`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_modified` (`modified`),
  KEY `idx_modified_by` (`modified_by`),
  KEY `idx_checked_out` (`checked_out`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xd6w5_workflows`
--

LOCK TABLES `xd6w5_workflows` WRITE;
/*!40000 ALTER TABLE `xd6w5_workflows` DISABLE KEYS */;
INSERT INTO `xd6w5_workflows` VALUES
(1,56,1,'COM_WORKFLOW_BASIC_WORKFLOW','','com_content.article',1,1,'2026-04-07 08:51:06',170,'2026-04-07 08:51:06',170,NULL,NULL),
(2,0,1,'Paper Lifecycle','eaiou peer review submission lifecycle: draft → submitted → under_review → decision_pending → accepted/rejected → published/archived.','com_content',0,1,'2026-04-07 13:21:05',42,'2026-04-07 13:21:05',0,NULL,NULL);
/*!40000 ALTER TABLE `xd6w5_workflows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xd6w5_workflow_stages`
--

DROP TABLE IF EXISTS `xd6w5_workflow_stages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `xd6w5_workflow_stages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) DEFAULT 0,
  `ordering` int(11) NOT NULL DEFAULT 0,
  `workflow_id` int(11) NOT NULL,
  `published` tinyint(4) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `default` tinyint(4) NOT NULL DEFAULT 0,
  `checked_out_time` datetime DEFAULT NULL,
  `checked_out` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_workflow_id` (`workflow_id`),
  KEY `idx_checked_out` (`checked_out`),
  KEY `idx_title` (`title`(191)),
  KEY `idx_asset_id` (`asset_id`),
  KEY `idx_default` (`default`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xd6w5_workflow_stages`
--

LOCK TABLES `xd6w5_workflow_stages` WRITE;
/*!40000 ALTER TABLE `xd6w5_workflow_stages` DISABLE KEYS */;
INSERT INTO `xd6w5_workflow_stages` VALUES
(1,57,1,1,1,'COM_WORKFLOW_BASIC_STAGE','',1,NULL,NULL),
(2,0,1,2,1,'Draft','Author preparing the submission.',0,NULL,NULL),
(3,0,1,2,1,'Submitted','Author submitted. Awaiting editor assignment.',0,NULL,NULL),
(4,0,1,2,1,'Under Review','Assigned to reviewers. Awaiting reports.',0,NULL,NULL),
(5,0,1,2,1,'Decision Pending','All reviews received. Editor deliberating.',0,NULL,NULL),
(6,0,1,2,1,'Revisions Requested','Author must revise before re-evaluation.',0,NULL,NULL),
(7,0,1,2,1,'Accepted','Paper accepted. Awaiting Zenodo capstone + publish.',0,NULL,NULL),
(8,0,1,2,1,'Published','Live and public. q_signal is the discovery key.',1,NULL,NULL),
(9,0,1,2,1,'Archived','Tombstoned (rejected or withdrawn). Never deleted.',0,NULL,NULL);
/*!40000 ALTER TABLE `xd6w5_workflow_stages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xd6w5_workflow_transitions`
--

DROP TABLE IF EXISTS `xd6w5_workflow_transitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `xd6w5_workflow_transitions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) DEFAULT 0,
  `ordering` int(11) NOT NULL DEFAULT 0,
  `workflow_id` int(11) NOT NULL,
  `published` tinyint(4) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `from_stage_id` int(11) NOT NULL,
  `to_stage_id` int(11) NOT NULL,
  `options` text NOT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  `checked_out` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_title` (`title`(191)),
  KEY `idx_asset_id` (`asset_id`),
  KEY `idx_checked_out` (`checked_out`),
  KEY `idx_from_stage_id` (`from_stage_id`),
  KEY `idx_to_stage_id` (`to_stage_id`),
  KEY `idx_workflow_id` (`workflow_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xd6w5_workflow_transitions`
--

LOCK TABLES `xd6w5_workflow_transitions` WRITE;
/*!40000 ALTER TABLE `xd6w5_workflow_transitions` DISABLE KEYS */;
INSERT INTO `xd6w5_workflow_transitions` VALUES
(1,58,1,1,1,'UNPUBLISH','',-1,1,'{\"publishing\":\"0\"}',NULL,NULL),
(2,59,2,1,1,'PUBLISH','',-1,1,'{\"publishing\":\"1\"}',NULL,NULL),
(3,60,3,1,1,'TRASH','',-1,1,'{\"publishing\":\"-2\"}',NULL,NULL),
(4,61,4,1,1,'ARCHIVE','',-1,1,'{\"publishing\":\"2\"}',NULL,NULL),
(5,62,5,1,1,'FEATURE','',-1,1,'{\"featuring\":\"1\"}',NULL,NULL),
(6,63,6,1,1,'UNFEATURE','',-1,1,'{\"featuring\":\"0\"}',NULL,NULL),
(7,64,7,1,1,'PUBLISH_AND_FEATURE','',-1,1,'{\"publishing\":\"1\",\"featuring\":\"1\"}',NULL,NULL),
(8,0,1,2,1,'Author Submits','Author finalizes and submits.',2,3,'{}',NULL,NULL),
(9,0,1,2,1,'Editor Assigns Reviewers','Editor assigns reviewers and opens review phase.',3,4,'{}',NULL,NULL),
(10,0,1,2,1,'Reviews Complete','All reviewer reports received.',4,5,'{}',NULL,NULL),
(11,0,1,2,1,'Request Revisions','Editor requests author revisions.',5,6,'{}',NULL,NULL),
(12,0,1,2,1,'Author Resubmits','Author uploads revised version for re-evaluation.',6,3,'{}',NULL,NULL),
(13,0,1,2,1,'Accept Paper','Editor accepts the paper.',5,7,'{}',NULL,NULL),
(14,0,1,2,1,'Publish Paper','Editor publishes the paper (Zenodo capstone required).',7,8,'{}',NULL,NULL),
(15,0,1,2,1,'Reject Paper','Editor rejects (tombstone — never deleted).',5,9,'{}',NULL,NULL),
(16,0,1,2,1,'Desk Reject','Editor desk-rejects without sending to review.',3,9,'{}',NULL,NULL),
(17,0,1,2,1,'Withdraw Draft','Author withdraws before submission.',2,9,'{}',NULL,NULL),
(18,0,1,2,1,'Withdraw Submitted','Author withdraws after submission.',3,9,'{}',NULL,NULL),
(19,0,1,2,1,'Return to Draft','Editor returns to author for pre-submission work.',3,2,'{}',NULL,NULL);
/*!40000 ALTER TABLE `xd6w5_workflow_transitions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-04-07 15:24:13
